#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# (c) ACE 

import os

class Config(object):
    # get a token from @BotFather
    pass
    """
    BOT_TOKEN = os.environ.get("BOT_TOKEN", "7363610742:AAHRdYOwGwg63pc3xnnFh1ZsEDDsOdhTpOM")
    API_ID = int(os.environ["API_ID", 21179966]
    API_HASH = os.environ["API_HASH", "d97919fb0a3c725e8bb2a25bbb37d57c"]
    AUTH_USERS = "7326397503"""
 
