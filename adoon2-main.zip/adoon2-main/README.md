# Please edit your userid in repo . open main.py 》 line no. 24  & line no. 27 change owner id and admin id . then bot will work properly... 


# Deploy To Heroku

[![Deploy To Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Rohanthakur360/New_Txt_Random)
